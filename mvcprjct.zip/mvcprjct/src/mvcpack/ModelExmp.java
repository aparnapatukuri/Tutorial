package mvcpack;

public class ModelExmp {
String name,pd;
	public void accept(String us,String pw)
	{
		name=us;
		pd=pw;
	}
	public boolean LoginValidation()
	{
		
	if(name.equals("aparna")&&pd.equals("1347"))
	{
		return true;
	
    }
	else
	{
		return false;
	}
	}
}
